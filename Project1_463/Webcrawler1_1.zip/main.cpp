/*
	Created by: Austin Fisher
	Class:	    CSCE 463
	Section:    500
*/
#include "Socket.h"
#include "HTMLParserBase.h"
#include <string.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <iostream>
#include <stdio.h>

using namespace std;
struct UrlObj {
	string scheme;
	string host;
	int port = 80;
	string path = "/"; // Initial value if no path provided
	string query;
	string request() {
		return path + query;
	}
};



int main(int argc, char **argv)
{
	DWORD t_total = timeGetTime();
	WSADATA wsaData;

	//Initialize WinSock; once per program run
	WORD wVersionRequested = MAKEWORD(2, 2);
	if (WSAStartup(wVersionRequested, &wsaData) != 0) {
		printf("WSAStartup error %d\n", WSAGetLastError());
		WSACleanup();
		return -1;
	}
	if (argc != 2) {
		printf("Unknown parameters!\n");
		printf("USAGE:\n  winsock.exe scheme://host[:port][/path][?query][#fragment]\n");
		return 1;
	}

	Socket sock;

	do {
		string url = string(argv[1]);
		UrlObj inputUrl;
		printf("URL: %s\n", argv[1]);
		printf("    Parsing URL ...");
		int scheme_end = url.find("://");
		if (scheme_end == string::npos) {
			printf("Could not find '://'! Are you sure you input a valid address?\n");
			break;
		}
		inputUrl.scheme = url.substr(0, scheme_end);
		if (inputUrl.scheme != "http") {
			printf("Invalid scheme, only 'http' is accepted\n");
			break;
		}
		// Remove the processed ends of the URL
		url = url.substr(scheme_end + 3);
		int fragment_start = url.find("#");
		if (fragment_start != string::npos)
			url = url.substr(0, fragment_start);
		// Look for port, path, query
		int port_start = url.find(":");
		int path_start = url.find("/");
		int query_start = url.find("?");
		if (query_start != string::npos && path_start > query_start)
			path_start = string::npos;
		if (path_start != string::npos && port_start > path_start
			|| query_start != string::npos && port_start > query_start)
			port_start = string::npos;

		// Host is whatever is before port. If no port, whatever is before path, ...
		if (port_start != string::npos)
			inputUrl.host = url.substr(0, port_start);
		else if (path_start != string::npos)
			inputUrl.host = url.substr(0, path_start);
		else if (query_start != string::npos)
			inputUrl.host = url.substr(0, query_start);
		else
			inputUrl.host = url;
		if (port_start != string::npos)
		{
			// There is a port. Ends at either '/', '?', or end of input
			string port;
			if (path_start == string::npos && query_start == string::npos)
				port = url.substr(port_start + 1);
			else if (path_start != string::npos)
				port = url.substr(port_start + 1, path_start - port_start - 1);
			else if (query_start != string::npos)
				port = url.substr(port_start + 1, query_start - port_start - 1);
			// Convert port to int
			if (port.size() != 0) {
				try {
					inputUrl.port = stoi(port);
				}
				catch (...) {
					printf("Could not convert port to number! Are you sure it is correct?\n");
					break;
				}
			}
		}
		if (path_start != string::npos) {
			// There is a path. Ends at either '?', or end of input
			if (query_start == string::npos)
				inputUrl.path = url.substr(path_start);
			else if (query_start != string::npos) {
				inputUrl.path = url.substr(path_start, query_start - path_start);
			}
		}
		if (query_start != string::npos) {
			inputUrl.query = url.substr(query_start);
		}

		
		printf(" host %s, port %i, request %s\n", inputUrl.host.c_str(), inputUrl.port, inputUrl.request().c_str());
		printf("    Doing DNS... ");

		if (!sock.Open()) {
			printf("Failed to open socket!\n");
			break;
		}

		// Transform DNS
		DWORD t = timeGetTime();

		if (!sock.DNS(inputUrl.host.c_str())) {
			printf("Failed to lookup DNS! \n");
			break;
		}
		printf("done in %d ms, found %s\n", timeGetTime() - t, inet_ntoa(sock.server.sin_addr));
		printf("  * Connecting on page... ");
		// Connect to page
		t = timeGetTime();
		// connect to the server on the requested port
		if (!sock.Connect(inputUrl.port)) {
			printf("Failed to connect to port!\n");
			break;
		}
		printf("done in %d ms\n", timeGetTime() - t);
		printf("    Loading... ");
		// Download result
		//+ inputUrl.path + inputUrl.query
		string get_http = "GET " + inputUrl.request() + " HTTP/1.0\r\nHost: " + inputUrl.host + "\r\nUser-agent: FisherTAMUcrawler/1.1\r\nConnection: close\r\n\r\n";
		//string get_headers = "HEAD / HTTP/1.0 \r\nHost: " + inputUrl.host + "\r\nConnection: close\r\nUser-agent: FisherTAMUcrawler/1.1\r\n\r\n";
		//printf("\nSent request:%s", get_http.c_str());
		t = timeGetTime();
		if (!sock.Write(get_http.c_str())) {
			break;
		}
		if (!sock.Read()){
			break;
		}
		printf("done in %d ms with %i bytes\n", timeGetTime() - t, sock.curPos);
		printf("    Verifying header... ");

		// Check header code
		auto status = strstr(sock.buf, "HTTP/");
		if (status == NULL) {
			// Fail out of checking header code
			printf(" irregular location of status code, unable to parse!\n");
			break;
		}
		int status_code = -1;
		try {
			status_code = stoi(status + 9);
		}
		catch (...) {
			printf("Problem retriving status code from response!\n");
			break;
		}
		printf("status code %d\n", status_code);
		if (status_code < 200 || status_code >= 300) {
			break;
		}
		printf("  + Parsing page... ");
		// Parse page for links
		t = timeGetTime();
		HTMLParserBase *parser = new HTMLParserBase;
		int nLinks;
		char *linkBuffer = parser->Parse(sock.buf, sock.curPos, argv[1], strlen(argv[1]), &nLinks);

		// check for errors indicated by negative values
		if (nLinks < 0)
			nLinks = 0;

		printf("done in %d ms with %i links\n\n", timeGetTime() - t, nLinks);
		break;
	}while (true);
	// get current time; link with winmm.lib
	printf("\n======================================\n");
	//printf("%.*s\n",mySock.curPos,mySock.buf);
	auto headers = strstr(sock.buf, "\r\n\r\n");
	
	printf("%.*s\n", headers-sock.buf, sock.buf);
	/*FILE *fp;
	fopen_s(&fp, string(inputUrl.host + ".html").c_str(), "wb");
	fwrite(mySock.buf, 1, mySock.curPos, fp);
	fclose(fp);*/

	printf("\n\nterminating main(), completion time %d ms\n", timeGetTime() - t_total);


	// call cleanup when done with everything and ready to exit program
	WSACleanup();
	cin.ignore();
	return 0;
}